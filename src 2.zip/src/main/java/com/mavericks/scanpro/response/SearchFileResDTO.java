package com.mavericks.scanpro.response;

import java.util.ArrayList;
import java.util.HashMap;

public class SearchFileResDTO {
    private ArrayList<HashMap<String,String>> files ;
}
